from vpn_core import QVPN
from handshake import handshake
import socket, os

key, _ = handshake()
vpn = QVPN(bytes.fromhex(key))
nonce = os.urandom(12)

data = b"This is encrypted QVPN traffic."
encrypted = vpn.encrypt(data, nonce)

with socket.socket() as s:
    s.connect(("127.0.0.1", 1194))
    s.sendall(encrypted)
    print("[CLIENT] Encrypted sent.")