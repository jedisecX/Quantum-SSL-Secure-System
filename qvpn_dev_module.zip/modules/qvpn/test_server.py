from vpn_core import QVPN
from handshake import handshake
import socket, os

key, _ = handshake()
vpn = QVPN(bytes.fromhex(key))
nonce = os.urandom(12)

with socket.socket() as s:
    s.bind(("0.0.0.0", 1194))
    s.listen()
    conn, _ = s.accept()
    data = conn.recv(1024)
    decrypted = vpn.decrypt(data, nonce)
    print("[SERVER] Decrypted:", decrypted.decode())