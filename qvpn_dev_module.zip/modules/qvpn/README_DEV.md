# QVPN Developer Mode (Quantum SSL VPN Module)

## Purpose
This dev module simulates a secure VPN tunnel using QSSL-based quantum entropy for key negotiation and AES-GCM for encrypted transmission.

## Files
- `handshake.py`: Generates quantum-derived keys
- `vpn_core.py`: Handles encryption and tunnel logic
- `test_server.py`: Sample encrypted server
- `test_client.py`: Client that sends encrypted data

## Usage
1. Run `test_server.py`
2. Run `test_client.py`
3. Observe handshake and encrypted traffic

More to come: obfuscator, relay chain, and live dashboard hook-in.