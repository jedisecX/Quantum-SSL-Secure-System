import os
import hashlib
import secrets

def generate_qssl_keypair(entropy_path="../../core/entropy/core_entropy.bin"):
    with open(entropy_path, "rb") as f:
        entropy = f.read(64)
    private_key = hashlib.sha256(entropy + secrets.token_bytes(32)).digest()
    public_key = hashlib.sha256(private_key).hexdigest()
    return private_key.hex(), public_key

def handshake():
    priv, pub = generate_qssl_keypair()
    print(f"[QSSL] Private Key: {priv}")
    print(f"[QSSL] Public  Key: {pub}")
    return priv, pub