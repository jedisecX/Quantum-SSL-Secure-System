import socket
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

class QVPN:
    def __init__(self, session_key: bytes):
        self.key = session_key[:32]
        self.aesgcm = AESGCM(self.key)

    def encrypt(self, data: bytes, nonce: bytes):
        return self.aesgcm.encrypt(nonce, data, None)

    def decrypt(self, token: bytes, nonce: bytes):
        return self.aesgcm.decrypt(nonce, token, None)

    def tunnel(self, target_ip, port):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((target_ip, port))
            print("[QVPN] Tunnel open.")